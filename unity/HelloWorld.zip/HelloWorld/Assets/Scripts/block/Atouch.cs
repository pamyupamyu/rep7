﻿using UnityEngine;
using System.Collections;

public class Atouch : MonoBehaviour {


    // Use this for initialization
    void Start () {
        Vector3 pos = transform.position;
        Debug.Log(pos.y);
    }
	
	// Update is called once per frame
	void Update () {

    }
    private void OnTriggerEnter(Collider other)
    {
        Vector3 pos = transform.position;
        //上下判定がやりたい
        if (other.tag == "Bblock")
        {
            Debug.Log("B on A");
        }
        if (other.tag == "Cblock")
        {
            Debug.Log("C on A");
        }
        if (other.tag == "Ground")
        {
            Debug.Log("ontable A");
            Debug.Log(pos.y);
        }
    }
}
