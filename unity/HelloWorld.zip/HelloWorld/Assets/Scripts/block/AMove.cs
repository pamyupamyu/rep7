﻿using UnityEngine;
using System.Collections;

public class AMove : MonoBehaviour {

    private Rigidbody rgbd_;
    public GameObject BBlock; //Inspector設定にすると成功した
    public GameObject CBlock; //Inspector設定にすると成功した

    private void Awake()
    {
        rgbd_ = GetComponent<Rigidbody>();
    }

    private const float move_speed_ = 10.0f;
    public static bool a_catch = false;

    /*
    //共通引数を用いてすべてのブロックのソースにmovingを書くことで動かす
    public static int command_i = 0;
    public static bool command_end = true;
    void Block_Moving (string command)
    {
        Vector3 vel = rgbd_.velocity;
        Vector3 pos_a = transform.position;
        Vector3 pos_b = BBlock.transform.position;
        Vector3 pos_c = CBlock.transform.position;
        //各コマンドの時
        if (command.Equals("catch A"))
        {
            command_end = false;
            //重力を切り
            rgbd_.useGravity = false;
            //指定の位置までブロックを動かす
            while (vel.x <=0)
            {
                vel.x = -move_speed_;
                rgbd_.velocity = vel;
            }
            //戻す  これは動くかは分からん
            rgbd_.useGravity = true;
            command_end = true;
        }
        else if (command.Equals("put A"))
        {
            //重力を切り
            rgbd_.useGravity = false;
            //指定の位置までブロックを動かす
            while (vel.x <= 0)
            {
                vel.x = -move_speed_;
                rgbd_.velocity = vel;
            }
        }

    }
    */
    
	
    
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.D))
        {
            Debug.Log(a_catch);
        }
        //catch
        if (!a_catch && Input.GetKey(KeyCode.A))
        {
            rgbd_.useGravity = false;
            a_catch = true;
            BMove.b_catch = false;
            CMove.c_catch = false;
        }
        //release
        if (a_catch && Input.GetKey(KeyCode.R))
        {
            rgbd_.useGravity = true;
            a_catch = false;
            BMove.b_catch = false;
            CMove.c_catch = false;
        }
        //catch時のみ動く
        if (a_catch)
        {
            if (Input.GetKey(KeyCode.RightArrow))
            {
                Vector3 vel = rgbd_.velocity;
                vel.x = -move_speed_;
                rgbd_.velocity = vel;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                Vector3 vel = rgbd_.velocity;
                vel.x = move_speed_;
                rgbd_.velocity = vel;
            }
            else if (Input.GetKey(KeyCode.UpArrow))
            {
                Vector3 vel = rgbd_.velocity;
                vel.y = move_speed_;
                rgbd_.velocity = vel;
            }
            
            else
            {
                rgbd_.velocity = Vector3.zero;
            }
            
        }
    }
    
}
