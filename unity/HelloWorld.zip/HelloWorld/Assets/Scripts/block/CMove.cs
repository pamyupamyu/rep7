﻿using UnityEngine;
using System.Collections;

public class CMove : MonoBehaviour {

    private Rigidbody rgbd_;

    private void Awake()
    {
        rgbd_ = GetComponent<Rigidbody>();
    }

    private const float move_speed_ = 10.0f;
    public static bool c_catch = false;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.D))
        {
            Debug.Log(c_catch);
        }
        //catch
        if (!c_catch && Input.GetKey(KeyCode.C))
        {
            rgbd_.useGravity = false;
            AMove.a_catch = false;
            BMove.b_catch = false;
            c_catch = true;
        }
        //release
        if (c_catch && Input.GetKey(KeyCode.R))
        {
            rgbd_.useGravity = true;
            AMove.a_catch = false;
            BMove.b_catch = false;
            c_catch = false;
        }

        //catch時のみ動く
        if (c_catch)
        {
            if (Input.GetKey(KeyCode.RightArrow))
            {
                Vector3 vel = rgbd_.velocity;
                vel.x = -move_speed_;
                rgbd_.velocity = vel;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                Vector3 vel = rgbd_.velocity;
                vel.x = move_speed_;
                rgbd_.velocity = vel;
            }
            else if (Input.GetKey(KeyCode.UpArrow))
            {
                Vector3 vel = rgbd_.velocity;
                vel.y = move_speed_;
                rgbd_.velocity = vel;
            }
            else
            {
                rgbd_.velocity = Vector3.zero;
            }
        }
    }
}